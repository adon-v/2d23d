# 结构构建模块：处理柱子、通道和对象的创建
module StructureBuilder
  # 导入柱子
  
  def self.import_columns(columns_data, parent_group)
    inch_scale_factor = 25.4
    columns_data.each do |column_data|
      begin
        # 验证输入数据
        unless column_data && column_data["points"]
          puts "警告: 立柱数据不完整，跳过"
          next
        end
        
        points = column_data["points"].map { |point| Utils.validate_and_create_point(point) }.compact
        next if points.size < 3
        
        puts "创建立柱: #{column_data['name'] || column_data['id']}"
        puts "立柱点数: #{points.size}"
        
        # 验证点的有效性 - Geom::Point3d对象没有valid?方法
        valid_points = points.select { |pt| pt && pt.is_a?(Geom::Point3d) }
        if valid_points.size < 3
          puts "警告: 立柱有效点数不足，跳过"
          next
        end
        
        # 创建立柱组
        column_group = parent_group.entities.add_group
        column_group.name = column_data['name'] || "立柱"
        
        # 创建立柱面
        column_face = column_group.entities.add_face(valid_points)
        unless column_face && column_face.is_a?(Sketchup::Face)
          puts "警告: 无法创建立柱面，跳过"
          next
        end
        
        # 设置立柱高度 - 修复高度计算逻辑
        height = Utils.parse_number(column_data["height"] || 10000)
        height = 10000 if height <= 0  # 默认10米
        height = height / inch_scale_factor  # 转换为英寸
        
        # 拉伸立柱
        begin
          puts "开始拉伸立柱，高度: #{height}英寸"
          column_face.pushpull(-height)
          puts "立柱拉伸成功，高度: #{height}英寸 (#{height * 0.0254}米)"
        rescue => e
          puts "立柱拉伸失败: #{e.message}"
          puts "立柱数据: #{column_data.inspect}"
          puts "立柱点: #{valid_points.inspect}"
          # 即使拉伸失败，也保留立柱面
        end
        
        # 设置立柱材质和颜色
        begin
          column_face.material = [128, 128, 128]  # 灰色
          column_face.back_material = [128, 128, 128]
          puts "立柱材质设置成功"
        rescue => e
          puts "立柱材质设置失败: #{e.message}"
        end
        
        # 设置立柱属性
        begin
          column_group.set_attribute('FactoryImporter', 'type', 'column')
          column_group.set_attribute('FactoryImporter', 'column_name', column_data['name'] || '立柱')
          column_group.set_attribute('FactoryImporter', 'column_id', column_data['id'])
          column_group.set_attribute('FactoryImporter', 'id', column_data['id'])
          
          # 立柱面的属性
          column_face.set_attribute('FactoryImporter', 'element_type', 'column')
          column_face.set_attribute('FactoryImporter', 'column_name', column_data['name'] || '立柱')
          column_face.set_attribute('FactoryImporter', 'column_id', column_data['id'])
        rescue => e
          puts "立柱属性设置失败: #{e.message}"
        end
        
        # 存储到实体存储器
        begin
          if defined?(EntityStorage)
            EntityStorage.add_entity("column", column_group, {
              column_id: column_data['id'],
              column_name: column_data['name'] || '立柱',
              height: height * 0.0254,  # 转换为米
              points: valid_points.map { |p| [p.x, p.y, p.z] }
            })
            puts "立柱已存储到实体存储器"
          end
        rescue => e
          puts "存储立柱到实体存储器失败: #{e.message}"
        end
        
        puts "立柱创建成功: #{column_data['name'] || column_data['id']}"
        
      rescue => e
        puts "创建立柱失败: #{Utils.ensure_utf8(e.message)}"
        puts "立柱数据: #{column_data.inspect}"
      end
    end
  end
  

  # 导入对象
  def self.import_objects(objects_data, parent_group)
    objects_data.each do |object_data|
      begin
        position = Utils.validate_and_create_point(object_data["position"])
        next if !position
        
        size = object_data["size"] || []
        width = Utils.parse_number(size[0] || 1.0)
        length = Utils.parse_number(size[1] || 1.0)
        height = Utils.parse_number(size[2] || 1.0)
        
        width = 1.0 if width <= 0
        length = 1.0 if length <= 0
        height = 1.0 if height <= 0
        
        orientation = Utils.parse_number(object_data["orientation"] || 0.0)
        
        object_group = parent_group.entities.add_group
        object_group.name = object_data["type"] || "对象"
        
        points = [
          position,
          position + Geom::Vector3d.new(width, 0, 0),
          position + Geom::Vector3d.new(width, length, 0),
          position + Geom::Vector3d.new(0, length, 0)
        ]
        
        if orientation != 0
          rotation = Geom::Transformation.rotation(position, Geom::Vector3d.new(0, 0, 1), orientation * Math::PI / 180)
          points.map! { |p| p.transform(rotation) }
        end
        
        object_face = object_group.entities.add_face(points)
        object_face.pushpull(-height) if object_face
      rescue => e
        puts "创建对象失败: #{Utils.ensure_utf8(e.message)}"
      end
    end
  end
end 